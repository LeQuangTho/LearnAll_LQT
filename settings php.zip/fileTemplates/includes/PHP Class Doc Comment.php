/**
 * Class ${NAME}
 * 
 * @category 
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 * @author hoangky <hoangky@toprate.io>
 */
