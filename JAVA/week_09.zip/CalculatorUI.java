package week_09;

public class CalculatorUI {
	
	public static void main(String[] args) {
		CalculatorFrame frame = new CalculatorFrame();
		frame.setVisible(true);
	}

}
