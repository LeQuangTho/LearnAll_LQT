package com.example.customlistview;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class dong_sinh_vien extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_dong_sinh_vien);
    }
}
