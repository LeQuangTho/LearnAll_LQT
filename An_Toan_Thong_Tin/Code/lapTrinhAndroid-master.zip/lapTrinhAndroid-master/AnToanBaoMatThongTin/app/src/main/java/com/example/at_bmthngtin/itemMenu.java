package com.example.at_bmthngtin;

public class itemMenu {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public itemMenu(String name) {
        this.name = name;
    }
}
